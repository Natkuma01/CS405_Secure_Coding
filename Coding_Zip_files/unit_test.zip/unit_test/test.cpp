//  #include "pch.h"
#include "gtest/gtest.h"

//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}

// Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // is the collection empty?
  // if empty, the size must be 0
  ASSERT_TRUE(collection->empty());                  // this line run only when the collection is empty
  ASSERT_EQ(0, collection->size());                  // check if the expected value (0) is same as the actual value (collection->size)

  add_entries(1);

  // is the collection still empty?
  // if not empty, what must the size be?
  EXPECT_FALSE(collection->empty());                // expect this will not be empty
  EXPECT_EQ(1, collection->size());                 // since we add entries for one, we are expecting 1 = the collection->size here
}


// Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
  ASSERT_TRUE(collection->empty());                 // make sure the collection is empty 
  ASSERT_EQ(0, collection->size());                 // ensure we are starting at 0

  add_entries(5);

  EXPECT_FALSE(collection->empty());                // we are not expecting collection to be empty here
  EXPECT_EQ(5, collection->size());                 // the collection size should be equal to 5
}


// Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterThanOrEqualToSize)
{
  EXPECT_GE(collection->max_size(), collection->size());        // exppect the max size is greater

  add_entries(1);

  EXPECT_EQ(1, collection->size());                             // make sure the collection size is 1 after added 1 entry
  EXPECT_GE(collection->max_size(), collection->size());        // we are expecting the max size is bigger or equal
                                                                // to the collection size, NOT smaller
  add_entries(4);                                               // 1 + 4 = 5

  EXPECT_EQ(5, collection->size());                             // expecting 5 here
  EXPECT_GE(collection->max_size(), collection->size());

  add_entries(5);                                               // 5 + 5 = 10

  EXPECT_EQ(10, collection->size());                            // expecting 10 here
  EXPECT_GE(collection->max_size(), collection->size());        // expecting the max siz is greating than the collection size

}

// Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, CapacityGreaterThanOrEqualToSize)
{
  EXPECT_GE(collection->capacity(), collection->size());        // exppect the capacity size is greater

  add_entries(1);

  EXPECT_EQ(1, collection->size());                             // make sure the collection size is 1 after added 1 entry
  EXPECT_GE(collection->capacity(), collection->size());        // we are expecting the capacity size is bigger or equal
                                                                // to the collection size
  add_entries(4);                                               // 1 + 4 = 5

  EXPECT_EQ(5, collection->size());                             // expecting 5 here
  EXPECT_GE(collection->capacity(), collection->size());

  add_entries(5);                                               // 5 + 5 = 10

  EXPECT_EQ(10, collection->size());                            // expecting 10 here
  EXPECT_GE(collection->capacity(), collection->size());        // expecting the capacity is greater than the colection size 

}
// Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizingIncreases)
{
   add_entries(5);                                      // add 5 entries
   int originalSize = collection->size();                // set the variable originalSize as the collection size, which is 5
   
   collection->resize(10);                              // set the vector size become 10               

   EXPECT_EQ(collection->size(), 10);                   // we are expecting the collection size is equal to 10
   EXPECT_GE(collection->size(), originalSize);         // ensure that 10 is greater than the original 5
}

// Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizingDecrease)
{
  add_entries(10);                                      // add 10 entries
  int originalSize = collection->size();                // set originalSize as the collection size, which is 10

  collection->resize(5);                                // set the collection size as 5

  EXPECT_EQ(collection->size(), 5);                     // now we expect the collection size is 5
  EXPECT_LE(collection->size(), originalSize);          // expect the collection size should be less than the originalSize, 5 < 10 ==>True

}

// Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizingDecreaseToZero)
{
  add_entries(5);                                       // add 5 entries
  ASSERT_EQ(collection->size(), 5);                     // ensure the collention size is 5

  collection->resize(0);                                // now resize the collection to be 0, it should be empty

  EXPECT_EQ(collection->size(), 0);                     // we are expecting the collection size is 0
  EXPECT_TRUE(collection->empty());                     // we are expecting the collection is empty
}

// Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClearErases)
{
  add_entries(10);                                      // add 10 entries
  ASSERT_FALSE(collection->empty());                    // ensure that the collection should NOT be empty

  collection->clear();                                  // try to clear the collection

  EXPECT_TRUE(collection->empty());                     // expect the collection is empty now
  EXPECT_EQ(collection->size(), 0);                     // expect the collection size is equal to 0
}

// Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, EraseBeginToEnd)
{
  add_entries(10);                                      // add 10 entries
  ASSERT_EQ(collection->size(), 10);                    // ensure the collection size is 10 now

  auto begin_index = collection->begin() + 2;           // set the variable begin_index to be the second index
  auto end_index = collection->begin() + 4;             // set the variable begin_index to be the fourth index

  collection->erase(begin_index, end_index);            // erase from index 0 to the last index

  EXPECT_FALSE(collection->empty());                    // expect the collection is empty now
  EXPECT_EQ(collection->size(), 8);                     // expect the collection size is equal to 0
}

// Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreaseCapacityNotSize)
{
  add_entries(5);                                       // add 5 entries
  ASSERT_EQ(collection->size(), 5);                     // ensure the collection size is 5 now

  collection->reserve(10);                              // reserve 10 space in the collection

  EXPECT_EQ(collection->size(), 5);                     // expect the collection size not changed, remain as 5
  EXPECT_GE(collection->capacity(), 10);                // expect the capacity should be at least 10, so use GE instead of EQ
}

// Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrownOutOfRangeException)
{
  add_entries(5);                                         // add 5 entries

  EXPECT_THROW(collection->at(10), std::out_of_range);    // when try to access index 10, it throw error 
  EXPECT_THROW(collection->at(1000), std::out_of_range);  // when try to access index 1000, it throw error  (try to test with extreme large #)
  EXPECT_THROW(collection->at(-1), std::out_of_range);    // when try to access index -1, it throw error    (try to test with negative)
}

// =======================================================================================
//    Create 2 negative unit tests 
// =======================================================================================

// this test is to verify that cannot erase from an empty vector
TEST_F(CollectionTest, NoEraseFromEmptyVector)
{
  ASSERT_TRUE(collection->empty());                           // start with empty collection
  EXPECT_EQ(collection->begin(), collection->end());          // expect the beginning is equal to the end = 0, nothing to erase

  collection->erase(collection->begin(), collection->end());  // erase the collection from beginning to the end

  EXPECT_THROW(collection->at(0), std::out_of_range);         // after earasing, the vector is still empty, so index 0 is invalid
  EXPECT_EQ(collection->size(), 0);
}


// this test is to verify that requesting a size larger than the max_size will throw an length_error
TEST_F(CollectionTest, ResizeBeyondMaxThrowErr)
{
  size_t tooBig = collection->max_size() + 1;                 // find the absolute max the vector can handle
                                                              // add 1 to go beyond the limit

  // resize() will try to allocate space for 'tooBig' elements, but tooBig exceeds max_size() the vector cannot allocate
  // that much. We are expecting the operation throws an error                                                           
  EXPECT_THROW(collection->resize(tooBig), std::length_error);
}