// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>           // for standard exception
#include <string>              // for string in custom exception

// Create the custome exception class to define error message
// It is based on a standard error type
class MyCustomException : public std::runtime_error
{
public: 
    // Constructor - this runs when we create the error, it takes a message and passes it to the parent class
    MyCustomException(const std::string& message) : std::runtime_error(message) {}
};



bool do_even_more_custom_application_logic()
{

  std::cout << "Running Even More Custom Application Logic." << std::endl;

  // Throw any standard exception
  throw std::runtime_error("Something went wrong in the do_even_more_custom_application_logic function.");

  return true;
}
void do_custom_application_logic()
{
  //  Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  std::cout << "Running Custom Application Logic." << std::endl;

  // create try block that may throw an exception
  try
  {
    if(do_even_more_custom_application_logic()) 
    {
       std::cout << "The Even More Custom Application Logic Succeeded." << std::endl; 
    }
  }

  // catch the runtime error thrown above using const reference to avoid copying the exception
  catch(const std::exception& e)
  {
    // execution continues after thus catch block
    std::cerr << "Caught in do_custom_application_logic: " << e.what() << std::endl;
  }

  // throw a custom exception derived from std::exception and catch it in main()
  throw MyCustomException("Custom exception from do_custom_application_logic()");
  

    std::cout << "Even More Custom Application Logic Succeeded." << std::endl;

}

float divide(float num, float den)
{
  // Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception
  if (den == 0.0f) {
    throw std::runtime_error("Division by zero error in divide()");
  }
  return (num / den);
}

void do_division() noexcept
{
  // create test values for division operation
  // denominator will trigger a diviswion by zero error
  float numerator = 10.0f;
  float denominator = 0;

  // create try block to throw exception
  try {
  auto result = divide(numerator, denominator);
  std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }

  // create catch block to handle the runtime error (the type thrown by divide())
  // use const reference avoids copying exception object and prevents object slicing
  catch (const std::runtime_error& e) {

    // e.what() retrives the error message stored in the exception object
    // after this catch block, execution continues normally
    std::cerr << "Division Error caught: " << e.what() << std::endl;
  }
  
}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // create try block wraps all main program logic that might throw exceptions
  // this allows us to handle errors 
  try {
    do_division();
    do_custom_application_logic();
  }

  // catch the most specific exception type before the general ones
  catch (const MyCustomException& e) {
    std::cerr << "Main caught Custom Exception: " << e.what() << std::endl;
  }

  catch (const std::exception& e) {
    std::cerr << "Main caught Standard Exception: " << e.what() << std::endl;
  }

  // the (...) can catch ANY type of exceptions, even non-standard ones
  catch (...) {
    std::cout << "Caught unknown exception in main()" << std::endl;
  }
  return 0;
  
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu